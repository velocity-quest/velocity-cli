# Changelog

## 0.2.0

Preferred database collection commands now return typed connections with
`edges`, `pageInfo` and full filtered `totalCount`, and walk all cursor pages.
JSON scripts should read records from `data.edges[].node`. Existing array
commands remain under explicit `-legacy` names. New root commands also traverse
members, milestones, PRD links/versions, issue histories and other nested data.
Custom selections include required paging metadata, and missing or cycling
cursors fail rather than returning an incomplete result. Name resolution checks
every page before accepting an unambiguous match. Identity reads page and chunk
workspace memberships, preserving account/consent boundaries. New pages use
signed account/filter/grant-bound cursors, a 100-record ceiling, immutable
primary-key order and live authorization. Legacy browser arrays retain their
display order. REST workspace export completeness remains ENGIN-484.

## 0.1.2

Adds issue relation create/remove and self subscription commands. Dependencies
reject self-links and cycles, including concurrent writes; reverse dependencies
and symmetric related links are idempotent. Duplicate links preserve their
direction and do not change issue status. Subscriptions deliver update/comment
notifications, with actor suppression and current workspace membership checks.
Relation reads now return stable IDs and valid enums. Both relation endpoints
accept selected-workspace issue identifiers. Writes use the authenticated API.

## 0.1.1

Adds `velocity workspaces leave` / `vel workspaces leave` with live membership and
write-scope checks, atomic last-owner protection, and workspace credential cleanup.
A successful departure clears that account’s matching workspace default. Grants
that include the departed workspace require fresh sign-in and consent.

## 0.1.0

First general management CLI, independently released from `velocity-agent`.
Installs equivalent `velocity` and `vel` commands. Supports named account profiles,
PKCE sign-in, explicit workspace consent, refresh/revocation, scoped platform
operations, all API pagination modes, file/stdin input, ordered bulk operations,
loss-aware Markdown, version-checked rich-text imports, platform AI operations,
recorded notification polling, browser verification handoffs, diagnostics and completions.
The versioned coverage matrix records commands, handoffs and linked API gaps.
