# Changelog

## 0.1.1

Adds `velocity workspaces leave` / `vel workspaces leave` with live membership and
write-scope checks, atomic last-owner protection, and workspace credential cleanup.
A successful departure clears that account’s matching workspace default. Grants
that include the departed workspace require fresh sign-in and consent.

## 0.1.0

First general management CLI, independently released from `velocity-agent`.
Installs equivalent `velocity` and `vel` commands. Supports named account profiles,
PKCE sign-in, explicit workspace consent, refresh/revocation, scoped platform
operations, all API pagination modes, file/stdin input, ordered bulk operations,
loss-aware Markdown, version-checked rich-text imports, platform AI operations,
recorded notification polling, browser verification handoffs, diagnostics and completions.
The versioned coverage matrix records commands, handoffs and linked API gaps.
